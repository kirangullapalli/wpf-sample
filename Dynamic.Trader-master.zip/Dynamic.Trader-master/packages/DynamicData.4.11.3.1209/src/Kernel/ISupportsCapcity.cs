﻿
namespace DynamicData.Kernel
{
    internal interface ISupportsCapcity
    {
        int Capacity { get; set; }
        int Count { get; }
    }
}