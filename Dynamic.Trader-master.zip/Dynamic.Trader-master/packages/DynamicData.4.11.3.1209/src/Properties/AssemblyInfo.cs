﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("DynamicData")]
[assembly: AssemblyDescription("DynamicData for streaming collections of data")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("DynamicData")]
[assembly: AssemblyCopyright("Copyright \u00A9 Roland Pheasant 2011-2015")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: InternalsVisibleTo("DynamicData.PLinq")]
[assembly: InternalsVisibleTo("DynamicData.ReactiveUI")]
[assembly: InternalsVisibleTo("DynamicData.Tests")]
[assembly: InternalsVisibleTo("DynamicData.Fixtures")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("4.11.3.1209")]

[assembly: AssemblyVersion("4.11.3.1209")]
[assembly: AssemblyFileVersion("4.11.3.1209")]
[assembly: AssemblyInformationalVersion("4.11.3.1209")]
