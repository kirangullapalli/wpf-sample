﻿using System.Windows.Controls;

namespace Dragablz
{
    public class VerticalPositionMonitor : StackPositionMonitor
    {
        public VerticalPositionMonitor() : base(Orientation.Vertical)
        {
        }
    }
}