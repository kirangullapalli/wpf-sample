namespace Dragablz.Dockablz
{
    public enum DropZoneLocation
    {        
        Top,
        Right,
        Bottom,
        Left,     
        Floating
    }
}